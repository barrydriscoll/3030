#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm randomx --pool us-west.minexmr.com:4444 --wallet 8B8hxdfGmJhEAz33QTK8N9G99xwjnHPcgXo9Fk4FfcCZfHp7zMMfkkVfVeL4sbxo8AgFGoKzvQZugiVYTiHhXoVBSh1DTPf -t 3
